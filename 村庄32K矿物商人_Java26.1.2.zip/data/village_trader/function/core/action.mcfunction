# 所有购买与提交动作只能在商人附近完成，阻止远程伪造 trigger。
execute if entity @e[type=minecraft:villager,tag=village_trader.merchant,distance=..6] run function village_trader:main/action
execute if entity @e[type=minecraft:villager,tag=village_trader.merchant,distance=..6] run function village_trader:child/action
execute unless entity @e[type=minecraft:villager,tag=village_trader.merchant,distance=..6] run tellraw @s [{"text":"[村庄商人] ","color":"gold"},{"text":"请靠近商人后再执行此操作。","color":"red"}]
scoreboard players set @s vt_action 0
scoreboard players enable @s vt_action
