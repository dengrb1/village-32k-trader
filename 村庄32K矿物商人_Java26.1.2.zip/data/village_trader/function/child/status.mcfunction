tellraw @s [{"text":"===== 儿童守护线状态 =====","color":"gold","bold":true}]
execute if score @s vt_child matches 1 run tellraw @s {"text":"状态：启用","color":"green"}
execute unless score @s vt_child matches 1 run tellraw @s {"text":"状态：暂停","color":"yellow"}
tellraw @s [{"text":"核心章节：","color":"gray"},{"score":{"name":"@s","objective":"vt_cstage"},"color":"aqua"},{"text":" / 7  当前辅助：","color":"gray"},{"score":{"name":"@s","objective":"vt_caux"},"color":"light_purple"}]
tellraw @s [{"text":"目标进度 A/B/C：","color":"gray"},{"score":{"name":"@s","objective":"vt_ca"}},{"text":" / "},{"score":{"name":"@s","objective":"vt_cb"}},{"text":" / "},{"score":{"name":"@s","objective":"vt_cc"}}]
tellraw @s [{"text":"任务牌：所有权="},{"score":{"name":"@s","objective":"vt_cqown"}},{"text":" 激活="},{"score":{"name":"@s","objective":"vt_cactive"}},{"text":" 补领="},{"score":{"name":"@s","objective":"vt_cqrep"}}]
tellraw @s [{"text":"Boss章节：","color":"gray"},{"score":{"name":"@s","objective":"vt_bstage"}},{"text":" 激活="},{"score":{"name":"@s","objective":"vt_bactive"}},{"text":" 升格="},{"score":{"name":"@s","objective":"vt_asc"}}]
tellraw @s [{"text":"[当前任务]","color":"aqua","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 206"}},{"text":"  "},{"text":"[详细教程]","color":"green","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 208"}},{"text":"  "},{"text":"[夜视状态]","color":"light_purple","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 209"}}]

