execute unless score @s vt_child matches 1 run return 0
execute unless score @s vt_cqown matches 1 run tellraw @s {"text":"当前任务尚未购买并激活。","color":"red"}
execute unless score @s vt_cactive matches 1 run tellraw @s {"text":"当前任务尚未购买并激活。","color":"red"}
execute unless score @s vt_cqown matches 1 run return 0
execute unless score @s vt_cactive matches 1 run return 0
scoreboard players set @s vt_ok 0
execute if score @s vt_cstage matches 1 if score @s vt_ca matches 1.. if score @s vt_cb matches 1.. run scoreboard players set @s vt_ok 1
execute if score @s vt_cstage matches 2 if score @s vt_ca matches 16.. if score @s vt_cb matches 3.. run scoreboard players set @s vt_ok 1
execute if score @s vt_cstage matches 3 if score @s vt_ca matches 8.. if score @s vt_cb matches 1.. if score @s vt_cc matches 1.. run scoreboard players set @s vt_ok 1
execute if score @s vt_cstage matches 4 if score @s vt_ca matches 1.. if score @s vt_cb matches 3.. run scoreboard players set @s vt_ok 1
execute if score @s vt_cstage matches 5 if score @s vt_ca matches 1.. if score @s vt_cb matches 1.. if score @s vt_cc matches 1.. run scoreboard players set @s vt_ok 1
execute if score @s vt_cstage matches 6 if score @s vt_ca matches 1.. run scoreboard players set @s vt_ok 1
execute unless score @s vt_ok matches 1 run tellraw @s {"text":"普通目标尚未全部完成；任务牌不能提前提交。","color":"red"}
execute unless score @s vt_ok matches 1 run return 0
scoreboard players set @s vt_ok 0
execute if score @s vt_cstage matches 1 store result score @s vt_ok run clear @s minecraft:paper[minecraft:custom_data~{kind:"child_quest",id:1}] 1
execute if score @s vt_cstage matches 2 store result score @s vt_ok run clear @s minecraft:paper[minecraft:custom_data~{kind:"child_quest",id:2}] 1
execute if score @s vt_cstage matches 3 store result score @s vt_ok run clear @s minecraft:paper[minecraft:custom_data~{kind:"child_quest",id:3}] 1
execute if score @s vt_cstage matches 4 store result score @s vt_ok run clear @s minecraft:paper[minecraft:custom_data~{kind:"child_quest",id:4}] 1
execute if score @s vt_cstage matches 5 store result score @s vt_ok run clear @s minecraft:paper[minecraft:custom_data~{kind:"child_quest",id:5}] 1
execute if score @s vt_cstage matches 6 store result score @s vt_ok run clear @s minecraft:paper[minecraft:custom_data~{kind:"child_quest",id:6}] 1
execute unless score @s vt_ok matches 1 run tellraw @s {"text":"缺少与你当前章节一致的任务牌；辅助用品不能代替任务牌。","color":"red"}
execute unless score @s vt_ok matches 1 run return 0
scoreboard players set @s vt_cqown 0
scoreboard players set @s vt_cqrep 0
scoreboard players set @s vt_cactive 0
scoreboard players set @s vt_ca 0
scoreboard players set @s vt_cb 0
scoreboard players set @s vt_cc 0
scoreboard players add @s vt_cstage 1
execute if score @s vt_cstage matches 7 run scoreboard players set @s vt_bstage 1
execute if score @s vt_cstage matches 7 run tellraw @s {"text":"守护毕业！Boss 番外现已开放。","color":"gold","bold":true}
execute unless score @s vt_cstage matches 7 run tellraw @s {"text":"任务牌已消耗，下一章已解锁。","color":"green"}
