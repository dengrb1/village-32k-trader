execute unless score @s vt_child matches 1 run tellraw @s [{"text":"[儿童守护线] 当前未启用。管理员可执行 execute as <玩家> run function village_trader:child/enable","color":"yellow"}]
execute unless score @s vt_child matches 1 run return 0
tellraw @s [{"text":"===== 儿童守护商店 =====","color":"gold","bold":true}]
tellraw @s [{"text":"[已解锁资源]","color":"aqua","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 202"}},{"text":"  "},{"text":"[消耗品]","color":"green","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 203"}},{"text":"  "},{"text":"[当前装备]","color":"yellow","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 350"}}]
tellraw @s [{"text":"[必需任务道具]","color":"red","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 204"}},{"text":"  "},{"text":"[可选辅助用品]","color":"light_purple","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 205"}},{"text":"  "},{"text":"[当前任务与提交]","color":"gold","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 206"}}]
tellraw @s [{"text":"[Boss番外]","color":"dark_red","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 207"}},{"text":"  "},{"text":"[教程/设置]","color":"blue","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 208"}}]
tellraw @s [{"text":"普通商品固定 4 泥土；选中并携带商人徽章时为 1 泥土。任务牌和辅助用品始终使用标明材料。","color":"gray"}]

