tellraw @s [{"text":"===== 已解锁资源 =====","color":"aqua","bold":true}]
execute if score @s vt_cstage matches 2.. run tellraw @s {"text":"[4绿宝石] 4泥土/徽章1泥土","color":"green","click_event":{"action":"run_command","command":"/trigger vt_action set 303"}}
execute if score @s vt_cstage matches 3.. run tellraw @s {"text":"[1钻石] 4泥土/徽章1泥土","color":"aqua","click_event":{"action":"run_command","command":"/trigger vt_action set 304"}}
execute if score @s vt_cstage matches 4.. run tellraw @s [{"text":"[1钻石块]","color":"aqua","click_event":{"action":"run_command","command":"/trigger vt_action set 306"}},{"text":"  "},{"text":"[1绿宝石块]","color":"green","click_event":{"action":"run_command","command":"/trigger vt_action set 307"}}]
execute if score @s vt_cstage matches 5.. run tellraw @s [{"text":"[1下界合金碎片]","color":"dark_aqua","click_event":{"action":"run_command","command":"/trigger vt_action set 308"}},{"text":"  "},{"text":"[1下界合金锭]","color":"dark_gray","click_event":{"action":"run_command","command":"/trigger vt_action set 309"}}]
execute if score @s vt_cstage matches 6.. run tellraw @s {"text":"[1下界合金块]","color":"dark_purple","click_event":{"action":"run_command","command":"/trigger vt_action set 311"}}
tellraw @s {"text":"[返回]","color":"gray","click_event":{"action":"run_command","command":"/trigger vt_action set 1"}}

