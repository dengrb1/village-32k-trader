tellraw @s [{"text":"===== 当前章节详细教程 =====","color":"blue","bold":true}]
execute if score @s vt_cstage matches 1 run tellraw @s {"text":"先用4原木兑换任务牌。激活后重新收集任意原木至4个，并在2×2或工作台合成界面制作工作台。最后携带任务牌点击提交。","color":"white"}
execute if score @s vt_cstage matches 2 run tellraw @s {"text":"兑换任务牌后亲手破坏16个圆石方块；再用熔炉或高炉烧制铁矿石、深层铁矿石或粗铁。为保证来源可验证，请至少分3次从输出槽亲自取出铁锭。","color":"white"}
execute if score @s vt_cstage matches 3 run tellraw @s {"text":"兑换任务牌后放置普通火把8次，吃下任意食物一次，并成功睡床一次。三个记录都亮起后提交。","color":"white"}
execute if score @s vt_cstage matches 4 run tellraw @s {"text":"兑换任务牌后把盾牌放到副手；随后由你亲自击杀僵尸或骷髅，合计3只。","color":"white"}
execute if score @s vt_cstage matches 5 run tellraw @s {"text":"兑换任务牌后，在儿童资源或消耗品页买一次普通商品；亲手挖掘钻石矿或深层钻石矿1个；背包持有4绿宝石。","color":"white"}
execute if score @s vt_cstage matches 6 run tellraw @s {"text":"兑换守护任务牌后，右键本数据包生成的村庄商人一次，然后提交任务牌完成毕业。","color":"white"}
execute if score @s vt_cstage matches 7 run tellraw @s {"text":"核心毕业后依次购买并提交龙、凋灵、幽匿挑战书。只有挑战书已提交且章节激活时，亲手击杀对应 Boss 才会记录印记。","color":"white"}
tellraw @s [{"text":"任务牌和辅助用品身份完全分开；他人转交的任务牌没有你的所有权记录，不能提交。只会启用当前选择的一件辅助用品。","color":"gray"}]
tellraw @s [{"text":"[当前任务]","color":"green","click_event":{"action":"run_command","command":"/trigger vt_action set 206"}},{"text":"  "},{"text":"[夜视状态]","color":"light_purple","click_event":{"action":"run_command","command":"/trigger vt_action set 209"}},{"text":"  "},{"text":"[返回]","color":"gray","click_event":{"action":"run_command","command":"/trigger vt_action set 1"}}]
