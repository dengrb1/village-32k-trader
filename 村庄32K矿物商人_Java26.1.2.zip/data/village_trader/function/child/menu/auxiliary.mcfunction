tellraw @s [{"text":"===== 可选辅助用品 =====","color":"light_purple","bold":true}]
tellraw @s {"text":"点击未拥有项目会购买并选中；已拥有则仅切换。始终只有一个生效。","color":"gray"}
execute if score @s vt_cstage matches 1.. run tellraw @s {"text":"[1 伐木手套] 2皮革+2铁锭｜急迫I","click_event":{"action":"run_command","command":"/trigger vt_action set 331"}}
execute if score @s vt_cstage matches 2.. run tellraw @s {"text":"[2 矿工护符] 4铜锭+2红石｜急迫II、防火","click_event":{"action":"run_command","command":"/trigger vt_action set 332"}}
execute if score @s vt_cstage matches 3.. run tellraw @s {"text":"[3 旅行护符] 1指南针+4面包｜速度I、缓降","click_event":{"action":"run_command","command":"/trigger vt_action set 333"}}
execute if score @s vt_cstage matches 4.. run tellraw @s {"text":"[4 勇气护符] 4金锭+1金苹果｜抗性I、再生I","click_event":{"action":"run_command","command":"/trigger vt_action set 334"}}
execute if score @s vt_cstage matches 5.. run tellraw @s {"text":"[5 商人徽章] 8绿宝石｜普通商品1泥土、增强提示","click_event":{"action":"run_command","command":"/trigger vt_action set 335"}}
execute if score @s vt_cstage matches 6.. run tellraw @s {"text":"[6 守护护符] 1钻石+1图腾｜抗性II、再生II、防火、缓降","click_event":{"action":"run_command","command":"/trigger vt_action set 336"}}
tellraw @s [{"text":"[补领1]","click_event":{"action":"run_command","command":"/trigger vt_action set 341"}},{"text":" [2]","click_event":{"action":"run_command","command":"/trigger vt_action set 342"}},{"text":" [3]","click_event":{"action":"run_command","command":"/trigger vt_action set 343"}},{"text":" [4]","click_event":{"action":"run_command","command":"/trigger vt_action set 344"}},{"text":" [5]","click_event":{"action":"run_command","command":"/trigger vt_action set 345"}},{"text":" [6]","click_event":{"action":"run_command","command":"/trigger vt_action set 346"}}]
tellraw @s {"text":"[返回]","color":"gray","click_event":{"action":"run_command","command":"/trigger vt_action set 1"}}

