tellraw @s [{"text":"===== 必需任务道具 =====","color":"red","bold":true}]
execute if score @s vt_cstage matches 1 run tellraw @s {"text":"木工任务牌：4原木","color":"yellow"}
execute if score @s vt_cstage matches 2 run tellraw @s {"text":"矿工任务牌：3铁锭 + 8煤炭","color":"yellow"}
execute if score @s vt_cstage matches 3 run tellraw @s {"text":"旅途任务牌：8煤炭 + 8小麦","color":"yellow"}
execute if score @s vt_cstage matches 4 run tellraw @s {"text":"勇气任务牌：3腐肉 + 3骨头","color":"yellow"}
execute if score @s vt_cstage matches 5 run tellraw @s {"text":"商会任务牌：1钻石 + 4绿宝石","color":"yellow"}
execute if score @s vt_cstage matches 6 run tellraw @s {"text":"守护任务牌：1钻石 + 8金锭 + 1金苹果","color":"yellow"}
execute if score @s vt_cstage matches 7 run tellraw @s {"text":"核心六章已毕业；请查看 Boss 番外。","color":"green"}
execute if score @s vt_cstage matches 1..6 run tellraw @s [{"text":"[兑换并激活]","color":"green","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 321"}},{"text":"  "},{"text":"[免费补领一次]","color":"aqua","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 322"}},{"text":"  "},{"text":"[提交]","color":"gold","underlined":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 323"}}]
tellraw @s {"text":"[返回]","color":"gray","click_event":{"action":"run_command","command":"/trigger vt_action set 1"}}

