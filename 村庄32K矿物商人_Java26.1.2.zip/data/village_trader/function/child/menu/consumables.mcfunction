tellraw @s [{"text":"===== 已解锁消耗品 =====","color":"green","bold":true}]
execute if score @s vt_cstage matches 1.. run tellraw @s [{"text":"[8面包]","color":"yellow","click_event":{"action":"run_command","command":"/trigger vt_action set 301"}},{"text":"  "},{"text":"[16火把]","color":"gold","click_event":{"action":"run_command","command":"/trigger vt_action set 302"}}]
execute if score @s vt_cstage matches 3.. run tellraw @s {"text":"[1金苹果]","color":"gold","click_event":{"action":"run_command","command":"/trigger vt_action set 305"}}
execute if score @s vt_cstage matches 5.. run tellraw @s {"text":"[1不死图腾]","color":"yellow","click_event":{"action":"run_command","command":"/trigger vt_action set 310"}}
execute if score @s vt_cstage matches 6.. run tellraw @s {"text":"[1附魔金苹果]","color":"light_purple","click_event":{"action":"run_command","command":"/trigger vt_action set 312"}}
tellraw @s {"text":"[返回]","color":"gray","click_event":{"action":"run_command","command":"/trigger vt_action set 1"}}

