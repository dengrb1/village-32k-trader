tellraw @s [{"text":"旧章节装备：","color":"gray"},{"text":"[1]","click_event":{"action":"run_command","command":"/trigger vt_action set 351"}},{"text":" [2]","click_event":{"action":"run_command","command":"/trigger vt_action set 352"}},{"text":" [3]","click_event":{"action":"run_command","command":"/trigger vt_action set 353"}},{"text":" [4]","click_event":{"action":"run_command","command":"/trigger vt_action set 354"}},{"text":" [5]","click_event":{"action":"run_command","command":"/trigger vt_action set 355"}},{"text":" [6]","click_event":{"action":"run_command","command":"/trigger vt_action set 356"}}]
execute if score @s vt_asc matches 1 run function village_trader:child/equipment/tier_128
execute if score @s vt_asc matches 1 run return 1
execute if score @s vt_cstage matches 1 run function village_trader:child/equipment/tier_1
execute if score @s vt_cstage matches 2 run function village_trader:child/equipment/tier_3
execute if score @s vt_cstage matches 3 run function village_trader:child/equipment/tier_5
execute if score @s vt_cstage matches 4 run function village_trader:child/equipment/tier_10
execute if score @s vt_cstage matches 5 run function village_trader:child/equipment/tier_20
execute if score @s vt_cstage matches 6..7 run function village_trader:child/equipment/tier_32
