execute unless entity @s[type=minecraft:player] run return 0
tellraw @s [{"text":"[儿童夜视] ","color":"light_purple"},{"text":"启用="},{"score":{"name":"@s","objective":"vt_child"}},{"text":" 暂停剩余="},{"score":{"name":"@s","objective":"vt_nvpause"}},{"text":"秒 挂起模式="},{"score":{"name":"@s","objective":"vt_nvsusp"}},{"text":"（0正常/1安全/2强制）","color":"gray"}]

