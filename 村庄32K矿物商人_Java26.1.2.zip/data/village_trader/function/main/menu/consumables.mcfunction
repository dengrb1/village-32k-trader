tellraw @s [{"text":"\n【已解锁消耗品】","color":"yellow","bold":true}]
execute if score @s vt_stage matches 1 run tellraw @s [{"text":"完成第一阶段后开放消耗品。","color":"yellow"}]
execute if score @s vt_stage matches 2.. run tellraw @s [{"text":"[金苹果×8]","color":"gold","click_event":{"action":"run_command","command":"/trigger vt_action set 103"}}]
execute if score @s vt_stage matches 4.. run tellraw @s [{"text":"[附魔金苹果×2]","color":"light_purple","click_event":{"action":"run_command","command":"/trigger vt_action set 108"}}]
execute if score @s vt_stage matches 5.. run tellraw @s [{"text":"[不死图腾×1]","color":"yellow","click_event":{"action":"run_command","command":"/trigger vt_action set 109"}}]
tellraw @s [{"text":"[返回主菜单]","color":"gray","click_event":{"action":"run_command","command":"/trigger vt_action set 1"}}]

