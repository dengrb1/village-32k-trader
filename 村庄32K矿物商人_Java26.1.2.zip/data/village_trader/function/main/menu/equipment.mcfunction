tellraw @s [{"text":"\n【当前装备】","color":"aqua","bold":true},{"text":" 装备查看页=","color":"gray"},{"score":{"name":"@s","objective":"vt_gear"},"color":"yellow"},{"text":"（0为当前阶段）。装备回溯不影响资源解锁。","color":"gray"}]
execute if score @s vt_stage matches 1 run tellraw @s [{"text":"第一阶段尚未解锁成长装备。完成矿工试炼后开放 5 级钻石套装。","color":"yellow"}]
execute if score @s vt_stage matches 2.. run tellraw @s [{"text":"[兑换本页整套装备]","color":"green","click_event":{"action":"run_command","command":"/trigger vt_action set 150"}},{"text":"  [选择旧装备页]","color":"blue","click_event":{"action":"run_command","command":"/trigger vt_action set 70"}}]
tellraw @s [{"text":"[返回主菜单]","color":"gray","click_event":{"action":"run_command","command":"/trigger vt_action set 1"}}]
