tellraw @s [{"text":"\n【已解锁资源】","color":"green","bold":true},{"text":" 制裁价格在结算时统一验证。","color":"gray"}]
execute if score @s vt_stage matches 1 run tellraw @s [{"text":"完成第一阶段后开放资源兑换。","color":"yellow"}]
execute if score @s vt_stage matches 2.. run tellraw @s [{"text":"[钻石×64]","color":"aqua","click_event":{"action":"run_command","command":"/trigger vt_action set 101"}},{"text":"  [绿宝石×64]","color":"green","click_event":{"action":"run_command","command":"/trigger vt_action set 102"}}]
execute if score @s vt_stage matches 3.. run tellraw @s [{"text":"[钻石块×16]","color":"aqua","click_event":{"action":"run_command","command":"/trigger vt_action set 104"}},{"text":"  [绿宝石块×16]","color":"green","click_event":{"action":"run_command","command":"/trigger vt_action set 105"}},{"text":"  [下界合金碎片×16]","color":"dark_gray","click_event":{"action":"run_command","command":"/trigger vt_action set 106"}}]
execute if score @s vt_stage matches 4.. run tellraw @s [{"text":"[下界合金锭×8]","color":"dark_purple","click_event":{"action":"run_command","command":"/trigger vt_action set 107"}}]
execute if score @s vt_stage matches 6 run tellraw @s [{"text":"[下界合金块×4]","color":"dark_purple","bold":true,"click_event":{"action":"run_command","command":"/trigger vt_action set 110"}}]
tellraw @s [{"text":"[返回主菜单]","color":"gray","click_event":{"action":"run_command","command":"/trigger vt_action set 1"}}]

