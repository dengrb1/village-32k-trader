scoreboard players set @s vt_ok 1
execute store result score @s vt_tmp run clear @s minecraft:soul_sand 0
execute if score @s vt_tmp matches ..3 run scoreboard players set @s vt_ok 0
execute store result score @s vt_tmp run clear @s minecraft:obsidian 0
execute if score @s vt_tmp matches ..7 run scoreboard players set @s vt_ok 0
execute store result score @s vt_tmp run clear @s minecraft:enchanted_golden_apple 0
execute if score @s vt_tmp matches ..0 run scoreboard players set @s vt_ok 0
function village_trader:purchase/check_surcharge
execute if score @s vt_ok matches 1 run function village_trader:main/task/commit_5
execute if score @s vt_ok matches 0 run tellraw @s [{"text":"[村庄商人] 材料或制裁附加费不足，未扣除任何物品。","color":"red"}]

