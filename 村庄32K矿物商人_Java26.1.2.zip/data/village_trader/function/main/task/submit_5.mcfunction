scoreboard players set @s vt_ok 1
execute unless score @s vt_stage matches 5 run scoreboard players set @s vt_ok 0
execute unless score @s vt_qactive matches 5 run scoreboard players set @s vt_ok 0
execute unless score @s vt_qown matches 5 run scoreboard players set @s vt_ok 0
execute unless score @s vt_a matches 1.. run scoreboard players set @s vt_ok 0
execute unless score @s vt_b matches 1.. run scoreboard players set @s vt_ok 0
execute store result score @s vt_tmp run clear @s minecraft:paper[minecraft:custom_data~{kind:"main_quest",id:5}] 0
execute if score @s vt_tmp matches 0 run scoreboard players set @s vt_ok 0
execute if score @s vt_ok matches 1 run function village_trader:main/task/complete_5
execute if score @s vt_ok matches 0 run tellraw @s [{"text":"[村庄商人] 提交失败：本人所有权、正确任务道具和全部普通目标缺一不可。","color":"red"}]

