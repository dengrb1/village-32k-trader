advancement revoke @s only village_trader:main/kill_hostile
execute if score @s vt_child matches 0 if score @s vt_stage matches 1 if score @s vt_qactive matches 1 if score @s vt_b matches ..19 run scoreboard players add @s vt_b 1

